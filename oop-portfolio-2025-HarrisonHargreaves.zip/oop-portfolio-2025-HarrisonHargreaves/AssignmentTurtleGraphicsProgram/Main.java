package AssignmentTurtleGraphicsProgram;

public class Main 
{

    public static void main(String[] args) 
    {
        TurtleGraphics tg = new TurtleGraphics();
    }
}
