package code.week9;

public class Histogram {
    
}
