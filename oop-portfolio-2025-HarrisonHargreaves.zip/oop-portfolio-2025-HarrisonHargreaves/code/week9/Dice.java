/*package code.week9;

public class Dice implements Histogram(int steps){
    
    
}*/
