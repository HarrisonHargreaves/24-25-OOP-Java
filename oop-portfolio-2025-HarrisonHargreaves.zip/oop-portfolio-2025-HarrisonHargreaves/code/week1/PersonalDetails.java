package code.week1;

public class PersonalDetails {
    public static void main(String[] args) {
        System.out.println("================");
        System.out.println("Personal Details");
        System.out.println("================");
        System.out.println("Name: Harrison");
        System.out.println("Age: 19");
        System.out.println("Address: Leeds");
        System.out.println("================");
    }
}
